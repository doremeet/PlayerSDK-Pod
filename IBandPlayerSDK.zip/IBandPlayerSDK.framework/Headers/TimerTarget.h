//
//  TimerTarget.h
//  IBandPlayerSDK
//
//  Created by Yogev Barber on 03/09/2017.
//  Copyright © 2017 IBand. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimerTarget : NSObject
@property(weak, nonatomic) id realTarget;
@end
