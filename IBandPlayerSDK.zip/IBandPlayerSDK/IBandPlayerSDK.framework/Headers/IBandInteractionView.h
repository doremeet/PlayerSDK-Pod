//
//  IBandInteractionView.h
//  IBandPlayerSDK
//
//  Created by Yogev Barber on 12/02/2018.
//  Copyright © 2018 IBand. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IBandPlayerView.h"

@interface IBandInteractionView : UIViewController
-(void)setPlayerView:(IBandPlayerView *)playerView;
@end
